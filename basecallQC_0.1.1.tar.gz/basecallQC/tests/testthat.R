library(testthat)
library(basecallQC)

test_check("basecallQC")
